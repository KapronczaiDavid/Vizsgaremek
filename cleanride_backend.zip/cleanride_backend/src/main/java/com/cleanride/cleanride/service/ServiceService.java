package com.cleanride.cleanride.service;

import com.cleanride.cleanride.dto.request.CreateServiceRequest;
import com.cleanride.cleanride.dto.response.UserResponse;
import com.cleanride.cleanride.entity.Services;
import com.cleanride.cleanride.entity.Users;
import com.cleanride.cleanride.repository.ServiceRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

@Service
@RequiredArgsConstructor
public class ServiceService {


        private final ServiceRepository serviceRepository;

        @Transactional
        public UserResponse createUser(CreateServiceRequest request) {
            if (serviceRepository.existsByName(request.getName()) {
                throw new ResponseStatusException(HttpStatus.CONFLICT,
                        "Ez az név  már foglalt: " + request.getName());
            }

            Services saved = serviceRepository.createService(
                    request.getName(),
                    request.getDescription(),
                    request.getPrice(),
                    request.getDurationMinutes()

            return toResponseDto(saved);
        }
}
