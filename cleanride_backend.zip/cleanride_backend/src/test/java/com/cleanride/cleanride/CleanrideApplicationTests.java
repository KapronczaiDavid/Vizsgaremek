package com.cleanride.cleanride;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CleanrideApplicationTests {

	@Test
	void contextLoads() {
	}

}
